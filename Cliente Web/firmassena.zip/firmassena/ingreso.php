<?php session_start();


	$usuario = $_POST['usuario'];
	$password = $_POST['password'];
	$password = md5($password);
	try{
		
	include "conexion.php";
	}
	catch(PDOException $e){
	echo "Error: ". $e->getMessage();
	}

	$consulta = $conexion->prepare(
		"SELECT * FROM usuarios WHERE user = '$usuario' AND password= '$password';");

		
	$consulta ->execute();
	$consulta = $consulta ->fetchAll();
	$rows=$consulta->num_rows;
	if($rows>0){
	$resultado = $consulta->fetch_assoc();
		$_SESSION['usuario'] = strtoupper($usuario);
		$_SESSION['perfil'] = $resultado['perfil'];


		if($_SESSION['perfil']=="user"){
	echo '<script>
       window.location="home.php";
       </script>';

	}	
		
	else{
		header("Location: index.php");
	}
}
else{
	header("Location: index.php");
}


?>	
	