<!DOCTYPE html>
<html>
<head>
	<title>INICIO - SISTEMA BIOMETRICO DE FIRMAS</title>
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
<div class="titulo">
	<img src="logo.png" width="150" height="150">
<h1>SISTEMA BIOMETRICO DE FIRMAS + BLOCKCHAIN</h1>
</div>

<div class="sesion">
<form action="ingreso.php" method="POST">
	<label><b>USUARIO</b></label><br>
	<input type="text" name="user"><br><br>
	<label><b>CONTRASEÑA</b></label><br>
	<input type="password" name="pwd">
	<br><br><br>
	<input type="submit" name="ingresar" value="INGRESAR">
</form>
</div>

<div class="blockchain">
 <img src="blockchain.png">
	</div>

	<footer>
		<img src="centro.png" width="200" height="120">
		<img src="sennova.png" width="200" height="120">
	</footer>
</body>
</html>