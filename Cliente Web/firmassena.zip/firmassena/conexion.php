<?php

$conexion = new PDO('mysql:host=localhost;dbname=blockchain_cesge','root','Andresfmejia');


?>
